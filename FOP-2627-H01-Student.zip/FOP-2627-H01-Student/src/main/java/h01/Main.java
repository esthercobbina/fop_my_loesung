package h01;

import fopbot.*;
import fopbot.Robot;
import org.tudalgo.algoutils.student.annotation.DoNotTouch;
import org.tudalgo.algoutils.student.annotation.StudentImplementationRequired;

import java.awt.Color;


/**
 * Main entry point in executing the program.
 */
public class Main {

    public static int delay = 100;
    public static boolean isVisible = true;
    public static int worldHeight;
    public static int worldWidth;

    public static void main(String[] args) {
        //Do Not Touch the following three lines
        worldWidth = (Math.random() < 0.5) ? 7 : 9;
        worldHeight = 9;
        setupWorld();
        Robot redRob = new Robot(1, 4, Direction.RIGHT, 7, RobotFamily.SQUARE_RED);
        Robot blueRob = new Robot(worldWidth == 7 ? 3 : 4, 1, Direction.UP, 1, RobotFamily.SQUARE_BLUE);

        h1_1(redRob);
        blueRob = h1_2(blueRob);
        h1_3(redRob);
        h1_4(blueRob);
    }

    @StudentImplementationRequired("H1.1")
    public static void h1_1(Robot redRob) {
        redRob.putCoin();
        redRob.move();
    
        Robot redRob2;
        redRob2 = redRob;

        redRob2.putCoin();
        redRob2.move();
    }

    @StudentImplementationRequired("H1.2")
    public static Robot h1_2(Robot blueRob) {
        // 1. blueRob soll eine Münze ablegen
        blueRob.putCoin();
        
        // 2. blueRob soll einen Schritt in Blickrichtung gehen
        blueRob.move();
        
        // 3. blueRob soll einen Schritt nach links zum Boxenstopp gehen
        blueRob.turnLeft();
        blueRob.move();
        
        // 4. Neuen Roboter erstellen und in der Referenz blueRob speichern
        blueRob = new Robot((worldWidth == 7 ? 2 : 3) + 1, 2, Direction.UP, 8, RobotFamily.SQUARE_BLUE);
        
        // 5. Der neu erstellte blueRob soll eine Münze ablegen
        blueRob.putCoin();
        
        // 6. blueRob soll dann einen Schritt in Blickrichtung gehen
        blueRob.move();
        return blueRob;
    }

    @StudentImplementationRequired("H1.3")
        public static void h1_3(Robot redRob) {
            while (redRob.isFrontClear()) {
                redRob.putCoin();
                redRob.move();
            }
    }

    @StudentImplementationRequired("H1.4")
        public static void h1_4(Robot blueRob) {
            for (int i = 0; i < worldHeight - 4; i++) {
            blueRob.putCoin();
            blueRob.move();
        }
    }

    @DoNotTouch
    public static void setupWorld(){
        worldWidth = (Math.random() < 0.5) ? 7 : 9;
        worldHeight = 9;
        World.setSize(worldWidth, worldHeight);

        // Feld für Boxenstopp
        World.getGlobalWorld().getField(worldWidth == 7 ? 2 : 3,2).setFieldColor(Color.ORANGE);
        World.placeHorizontalWall(worldWidth == 7 ? 2 : 3, 2);
        World.placeHorizontalWall(worldWidth == 7 ? 2 : 3, 1);
        World.placeVerticalWall(worldWidth == 7 ? 1 : 2, 2);

        // Zielfelder
        World.getGlobalWorld().getField(worldWidth == 7 ? 3 : 4,worldHeight-1).setFieldColor(Color.BLUE);
        World.placeVerticalWall(worldWidth == 7 ? 2 : 3, worldHeight-1);
        World.placeVerticalWall(worldWidth == 7 ? 3 : 4, worldHeight-1);

        World.getGlobalWorld().getField(worldWidth-1,worldHeight/2).setFieldColor(Color.RED);
        World.placeHorizontalWall(worldWidth-1, worldHeight/2);
        World.placeHorizontalWall(worldWidth-1, worldHeight/2-1);

        World.setDelay(delay);
        World.setVisible(isVisible);
    }
}
